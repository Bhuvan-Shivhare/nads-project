import React, { useState, useEffect } from 'react';
import { Shield, Activity, Wifi, Key, AlertTriangle, RefreshCw } from 'lucide-react';

type Threat = {
  id?: number;
  ip: string;
  timestamp: string;
  status: string;
  packets?: string;
  ports?: string;
  type?: string;
  attempts?: number;
  user?: string;
};

type ThreatType = 'ddos' | 'portScan' | 'flooding' | 'loginAttempts';

function App() {
  const [selectedThreat, setSelectedThreat] = useState<ThreatType>('ddos');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [threats, setThreats] = useState<Record<ThreatType, Threat[]>>({
    ddos: [],
    portScan: [],
    flooding: [],
    loginAttempts: [],
  });

  const fetchThreats = async () => {
    try {
      const responses = await Promise.all([
        fetch('/results/ddos.json'),
                                          fetch('/results/port_scan.json'),
                                          fetch('/results/flooding.json'),
                                          fetch('/results/login_attempts.json'),
      ]);

      const [ddos, portScan, flooding, loginAttempts] = await Promise.all(
        responses.map(async (response) => {
          if (!response.ok) return [];
          try {
            return await response.json();
          } catch {
            return [];
          }
        })
      );

      setThreats({
        ddos: ddos.map((t: Threat, i: number) => ({ ...t, id: i })),
                 portScan: portScan.map((t: Threat, i: number) => ({ ...t, id: i })),
                 flooding: flooding.map((t: Threat, i: number) => ({ ...t, id: i })),
                 loginAttempts: loginAttempts.map((t: Threat, i: number) => ({ ...t, id: i })),
      });
    } catch (error) {
      console.error('Error fetching threats:', error);
    }
  };

  useEffect(() => {
    fetchThreats();
    const interval = setInterval(fetchThreats, 5000); // Refresh every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchThreats();
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  const renderThreatContent = () => {
    const currentThreats = threats[selectedThreat];

    if (currentThreats.length === 0) {
      return (
        <div className="p-8 text-center text-gray-500">
        No threats detected
        </div>
      );
    }

    return (
      <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
      <thead className="bg-gray-50">
      <tr>
      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">IP Address</th>
      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Timestamp</th>
      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Details</th>
      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
      </tr>
      </thead>
      <tbody className="bg-white divide-y divide-gray-200">
      {currentThreats.map((threat) => (
        <tr key={threat.id}>
        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{threat.ip}</td>
        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{threat.timestamp}</td>
        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        {selectedThreat === 'ddos' && threat.packets}
        {selectedThreat === 'portScan' && threat.ports}
        {selectedThreat === 'flooding' && threat.type}
        {selectedThreat === 'loginAttempts' && `${threat.attempts} attempts (${threat.user})`}
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
          threat.status === 'Blocked'
          ? 'bg-red-100 text-red-800'
          : 'bg-yellow-100 text-yellow-800'
        }`}>
        {threat.status}
        </span>
        </td>
        </tr>
      ))}
      </tbody>
      </table>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-100">
    <div className="flex h-screen">
    {/* Sidebar */}
    <div className="w-64 bg-gray-800">
    <div className="flex items-center justify-center h-16 bg-gray-900">
    <Shield className="h-8 w-8 text-blue-500" />
    <span className="ml-2 text-white font-semibold">NIDS Dashboard</span>
    </div>
    <nav className="mt-5">
    <button
    onClick={() => setSelectedThreat('ddos')}
    className={`flex items-center px-6 py-3 w-full ${
      selectedThreat === 'ddos' ? 'bg-gray-700 text-white' : 'text-gray-300 hover:bg-gray-700'
    }`}
    >
    <Activity className="h-5 w-5" />
    <span className="ml-3">DDoS Attacks</span>
    </button>
    <button
    onClick={() => setSelectedThreat('portScan')}
    className={`flex items-center px-6 py-3 w-full ${
      selectedThreat === 'portScan' ? 'bg-gray-700 text-white' : 'text-gray-300 hover:bg-gray-700'
    }`}
    >
    <Wifi className="h-5 w-5" />
    <span className="ml-3">Port Scans</span>
    </button>
    <button
    onClick={() => setSelectedThreat('flooding')}
    className={`flex items-center px-6 py-3 w-full ${
      selectedThreat === 'flooding' ? 'bg-gray-700 text-white' : 'text-gray-300 hover:bg-gray-700'
    }`}
    >
    <AlertTriangle className="h-5 w-5" />
    <span className="ml-3">Flooding</span>
    </button>
    <button
    onClick={() => setSelectedThreat('loginAttempts')}
    className={`flex items-center px-6 py-3 w-full ${
      selectedThreat === 'loginAttempts' ? 'bg-gray-700 text-white' : 'text-gray-300 hover:bg-gray-700'
    }`}
    >
    <Key className="h-5 w-5" />
    <span className="ml-3">Login Attempts</span>
    </button>
    </nav>
    </div>

    {/* Main content */}
    <div className="flex-1 overflow-auto">
    <div className="py-6 px-8">
    <div className="flex justify-between items-center mb-6">
    <h1 className="text-2xl font-semibold text-gray-900">
    {selectedThreat === 'ddos' && 'DDoS Attacks'}
    {selectedThreat === 'portScan' && 'Port Scans'}
    {selectedThreat === 'flooding' && 'Flooding Attacks'}
    {selectedThreat === 'loginAttempts' && 'Suspicious Login Attempts'}
    </h1>
    <button
    onClick={handleRefresh}
    className="flex items-center px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors"
    >
    <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
    Refresh
    </button>
    </div>
    <div className="bg-white shadow rounded-lg">
    {renderThreatContent()}
    </div>
    </div>
    </div>
    </div>
    </div>
  );
}

export default App;
