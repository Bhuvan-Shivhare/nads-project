from scapy.all import IP, TCP, UDP
from collections import defaultdict
import time

class DDoSDetector:
    def __init__(self, threshold=1000, window=60):
        self.threshold = threshold  # packets per window
        self.window = window  # time window in seconds
        self.packet_counts = defaultdict(list)
        
    def analyze_packet(self, packet):
        if IP in packet:
            src_ip = packet[IP].src
            current_time = time.time()
            
            # Add new packet timestamp
            self.packet_counts[src_ip].append(current_time)
            
            # Remove old packets outside the window
            self.packet_counts[src_ip] = [
                t for t in self.packet_counts[src_ip] 
                if current_time - t <= self.window
            ]
            
            # Check if packet count exceeds threshold
            if len(self.packet_counts[src_ip]) > self.threshold:
                return {
                    'ip': src_ip,
                    'packets': len(self.packet_counts[src_ip]),
                    'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
                    'status': 'Detected'
                }
        return None