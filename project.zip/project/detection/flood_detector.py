from scapy.all import IP, TCP, UDP
from collections import defaultdict
import time

class FloodDetector:
    def __init__(self, syn_threshold=100, window=60):
        self.syn_threshold = syn_threshold
        self.window = window
        self.syn_counts = defaultdict(list)

    def analyze_packet(self, packet):
        if IP in packet and TCP in packet:
            src_ip = packet[IP].src
            current_time = time.time()

            # Check for SYN flood
            if packet[TCP].flags & 0x02:  # SYN flag
                self.syn_counts[src_ip].append(current_time)

                # Remove old SYN attempts
                self.syn_counts[src_ip] = [
                    t for t in self.syn_counts[src_ip]
                    if current_time - t <= self.window
                ]

                # Check if SYN count exceeds threshold
                if len(self.syn_counts[src_ip]) > self.syn_threshold:
                    return {
                        'ip': src_ip,
                        'type': 'SYN Flood',
                        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
                        'status': 'Detected'
                    }
        return None
