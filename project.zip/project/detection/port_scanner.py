from scapy.all import IP, TCP
from collections import defaultdict
import time

class PortScanDetector:
    def __init__(self, threshold=20, window=60):
        self.threshold = threshold  # number of different ports
        self.window = window  # time window in seconds
        self.scan_attempts = defaultdict(lambda: defaultdict(list))

    def analyze_packet(self, packet):
        if IP in packet and TCP in packet:
            src_ip = packet[IP].src
            dst_port = packet[TCP].dport
            current_time = time.time()

            # Add new port scan attempt
            self.scan_attempts[src_ip]['ports'].append(dst_port)
            self.scan_attempts[src_ip]['timestamps'].append(current_time)

            # Remove old attempts outside the window
            current_ports = []
            current_timestamps = []
            for port, timestamp in zip(
                self.scan_attempts[src_ip]['ports'],
                self.scan_attempts[src_ip]['timestamps']
            ):
                if current_time - timestamp <= self.window:
                    current_ports.append(port)
                    current_timestamps.append(timestamp)

            self.scan_attempts[src_ip]['ports'] = current_ports
            self.scan_attempts[src_ip]['timestamps'] = current_timestamps

            # Check if unique ports exceed threshold
            unique_ports = len(set(current_ports))
            if unique_ports > self.threshold:
                return {
                    'ip': src_ip,
                    'ports': f'{min(current_ports)}-{max(current_ports)}',
                    'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
                    'status': 'Detected'
                }
        return None
