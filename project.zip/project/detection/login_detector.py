from collections import defaultdict
import time

class LoginAttemptDetector:
    def __init__(self, threshold=5, window=300):
        self.threshold = threshold
        self.window = window
        self.login_attempts = defaultdict(lambda: defaultdict(list))
        
    def analyze_login(self, ip, username, success=False):
        current_time = time.time()
        
        # Record attempt
        self.login_attempts[ip]['timestamps'].append(current_time)
        self.login_attempts[ip]['usernames'].append(username)
        
        # Remove old attempts
        current_timestamps = []
        current_usernames = []
        for timestamp, uname in zip(
            self.login_attempts[ip]['timestamps'],
            self.login_attempts[ip]['usernames']
        ):
            if current_time - timestamp <= self.window:
                current_timestamps.append(timestamp)
                current_usernames.append(uname)
        
        self.login_attempts[ip]['timestamps'] = current_timestamps
        self.login_attempts[ip]['usernames'] = current_usernames
        
        # Check if attempts exceed threshold
        if len(current_timestamps) > self.threshold:
            return {
                'ip': ip,
                'attempts': len(current_timestamps),
                'user': username,
                'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
                'status': 'Detected'
            }
        return None