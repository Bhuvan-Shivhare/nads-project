from scapy.all import sniff
from ddos_detector import DDoSDetector
from port_scanner import PortScanDetector
from flood_detector import FloodDetector
from login_detector import LoginAttemptDetector
import json
import os
from datetime import datetime

class NetworkMonitor:
    def __init__(self):
        self.ddos_detector = DDoSDetector()
        self.port_scanner = PortScanDetector()
        self.flood_detector = FloodDetector()
        self.login_detector = LoginAttemptDetector()

        # Create results directory if it doesn't exist
        if not os.path.exists('results'):
            os.makedirs('results')

    def print_threat(self, threat_type, result):
        """Print threat information to CLI in a formatted way"""
        print("\n" + "="*50)
        print(f"⚠️  {threat_type.upper()} THREAT DETECTED")
        print("="*50)
        print(f"🕒 Timestamp: {result['timestamp']}")
        print(f"🌐 IP Address: {result['ip']}")

        if threat_type == 'ddos':
            print(f"📊 Packets: {result['packets']}")
        elif threat_type == 'port_scan':
            print(f"🔍 Port Range: {result['ports']}")
        elif threat_type == 'flooding':
            print(f"🌊 Type: {result['type']}")
        elif threat_type == 'login_attempts':
            print(f"👤 Username: {result['user']}")
            print(f"🔄 Attempts: {result['attempts']}")

        print(f"📍 Status: {result['status']}")
        print("="*50 + "\n")

    def packet_callback(self, packet):
        # Check for DDoS
        ddos_result = self.ddos_detector.analyze_packet(packet)
        if ddos_result:
            self.save_result('ddos', ddos_result)
            self.print_threat('ddos', ddos_result)

        # Check for Port Scan
        scan_result = self.port_scanner.analyze_packet(packet)
        if scan_result:
            self.save_result('port_scan', scan_result)
            self.print_threat('port_scan', scan_result)

        # Check for Flooding
        flood_result = self.flood_detector.analyze_packet(packet)
        if flood_result:
            self.save_result('flooding', flood_result)
            self.print_threat('flooding', flood_result)

    def check_login_attempt(self, ip, username, success=False):
        login_result = self.login_detector.analyze_login(ip, username, success)
        if login_result:
            self.save_result('login_attempts', login_result)
            self.print_threat('login_attempts', login_result)

    def save_result(self, attack_type, result):
        filename = f'results/{attack_type}.json'

        # Read existing results
        existing_results = []
        if os.path.exists(filename):
            with open(filename, 'r') as f:
                try:
                    existing_results = json.load(f)
                except json.JSONDecodeError:
                    existing_results = []

        # Add new result
        existing_results.append(result)

        # Save updated results
        with open(filename, 'w') as f:
            json.dump(existing_results, f, indent=2)

def main():
    monitor = NetworkMonitor()

    print("\n🛡️  Network Intrusion Detection System")
    print("="*50)
    print("Monitoring for:")
    print("  • DDoS Attacks")
    print("  • Port Scans")
    print("  • Flooding Attacks")
    print("  • Suspicious Login Attempts")
    print("="*50)
    print("\nStarting network monitoring...\n")

    try:
        # Start packet capture
        sniff(prn=monitor.packet_callback, store=0)
    except KeyboardInterrupt:
        print("\n\n🛑 Stopping network monitoring...")
        print("="*50)
        print("Monitor stopped safely. Goodbye!")

if __name__ == "__main__":
    main()
